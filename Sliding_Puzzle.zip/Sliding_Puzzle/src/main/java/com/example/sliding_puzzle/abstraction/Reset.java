package com.example.sliding_puzzle.abstraction;

public class Reset {
}
